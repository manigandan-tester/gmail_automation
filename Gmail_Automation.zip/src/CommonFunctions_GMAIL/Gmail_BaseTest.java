package CommonFunctions_GMAIL;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import POM_GMAIL.GMail_Login_POM;

public class Gmail_BaseTest {
	public static WebDriver driver;

	//@BeforeSuite
	@BeforeMethod
	public void Precondition() throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://mail.google.com/mail/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		GMail_Login_POM CP = new GMail_Login_POM(driver);
		PageFactory.initElements(driver, CP );

		CP.setUserName("tengineer44@gmail.com");
		CP.ClickENext();
		//Thread.sleep(3000);
		CP.setPassword("Test@123");
		Thread.sleep(3000);
		CP.ClickPNext();
	}

	//@AfterSuite
	@AfterMethod
	public void Postcondition() throws InterruptedException
	{
		///*
		Thread.sleep(5000);
		GMail_Login_POM CP = new GMail_Login_POM(driver);
		PageFactory.initElements(driver, CP );
		CP.Signout();
		driver.switchTo().frame("account");
		CP.signout();
		driver.close();

		//*/
		//	driver.close();
	}
}

