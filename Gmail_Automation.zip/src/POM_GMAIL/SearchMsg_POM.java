package POM_GMAIL;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchMsg_POM {
	@FindBy(name="q")
	private WebElement Search; 
	
	@FindBy(xpath="(//span[text()='KEYWORDS'])[1]")
	private WebElement GetMsg; 
	
	//@FindBy(xpath="(//div[@aria-label='Older'])[3]")
	//private WebElement MsgMore;
	
	@FindBy(xpath="//div[@class='aSK J-J5-Ji aYr']")
	private WebElement FileDownload;
	
	
	
	
	
	public SearchMsg_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}

public void Searching() throws AWTException, InterruptedException
{
	Search.sendKeys("GMAIL KEYWORDS");
	Robot r = new Robot();
	r.keyPress(KeyEvent.VK_DOWN);
	r.keyRelease(KeyEvent.VK_DOWN);
	r.keyPress(KeyEvent.VK_ENTER);
	r.keyRelease(KeyEvent.VK_ENTER); 
	Thread.sleep(2000);
	GetMsg.click();
	Thread.sleep(3000);
	
}
public void Download() throws InterruptedException
{
	FileDownload.click();
	Thread.sleep(2000);
}
}
