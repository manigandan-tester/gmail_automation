package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InboX_POM {
	@FindBy(xpath="//div[@aria-label='Main menu']")
	public WebElement Menu;

	@FindBy(xpath="//a[text()='Inbox']")
	public WebElement InboxButton;

	@FindBy(xpath="//div[text()='Primary']")
	public WebElement Primary;

	@FindBy(xpath="//div[text()='Promotions']")
	public WebElement Promotions;

	@FindBy(xpath="//div[text()='Social']")
	public WebElement Social;

	@FindBy(xpath="//span[@class='l8 LJOhwe']")
	public WebElement Details;

	@FindBy(xpath="//span[@class='lk'and@id='show0']")
	public WebElement ShowDetails;
	
	@FindBy(xpath="//div[@class='T-I J-J5-Ji nu T-I-ax7 L3']")
	public WebElement Refresh;
	
	public InboX_POM (WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}

	
	
}
