package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CategorieS_POM {

	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="(//div[@class='G-asx J-J5-Ji'])[1]")
	private WebElement More2;
	
	@FindBy(xpath="(//div[@class='qj '])[12]")
	private WebElement categories;
	
	@FindBy(xpath="(//span//a[@class='J-Ke n0'])[13]")
	private WebElement Social;
	
	@FindBy(xpath="(//span//a[@class='J-Ke n0'])[14]")
	private WebElement Updates;
	
	@FindBy(xpath="(//span//a[@class='J-Ke n0'])[15]")
	private WebElement Forums;
	
	@FindBy(xpath="(//span//a[@class='J-Ke n0'])[16]")
	private WebElement Promotions;
	
	@FindBy(xpath="(//a[@class='gb_Zd gb_zc gb_Wd'and@aria-label='Gmail'])[2]")
	private WebElement logo;
	
	
	
	
	
	public CategorieS_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void Category() throws InterruptedException
	{
		 Menu.click();
		 More2.click();
		 categories.click();
		 Thread.sleep(1000); 
	}
	public void CatOptions() throws InterruptedException
	{
	   
		Social.click();
		Thread.sleep(1000);
		Updates.click();
		Thread.sleep(1000);
		Forums.click();
		Thread.sleep(1000);
		Promotions.click();
		Thread.sleep(2000);
		logo.click();
	}
	
}
