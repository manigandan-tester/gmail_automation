package POM_GMAIL;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ComposE_POM {
	@FindBy(xpath="//div[@role='button'and@class='T-I T-I-KE L3']")
	private WebElement CreateMail;
	
	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="//a[text()='Sent']")
	public WebElement Sent;
	
	@FindBy(xpath="//input[@class='agP aFw']")
	public WebElement To;
	
	@FindBy(xpath="//input[@name='subjectbox']")
	private WebElement Subject;
	
	@FindBy(xpath="//input[@class='agP aFw'and@id=':1ff']")
	private WebElement Cc;
	
	@FindBy(xpath="//input[@class='agP aFw'and@id=':1fh']")
	private WebElement Bcc;
	
	@FindBy(xpath="//div[@class='Am Al editable LW-avf tS-tW']")
	private WebElement MessageArea;
	
	@FindBy(xpath="//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']")
	private WebElement Send;
	
	@FindBy(xpath="//div[@class='wG J-Z-I']")
	private WebElement Attachment;
	
	@FindBy(xpath="//button[@class='a8v a8t Je']")
	private WebElement Emoji;
	
	@FindBy(xpath="//div[@class='QT aaA aMZ']")
	private WebElement Emote;
	
	@FindBy(xpath="//input[@class='biz']")
	private WebElement ESMIL;
	
	@FindBy(xpath="//button[@aria-label='grinning face']")
	private WebElement FaceEmote;
	
	@FindBy(xpath="(//a[@class='J-Ke n0'])[4]")
	private WebElement SentBox;
	
	@FindBy(xpath="//div[@class='TN bzz aHS-bnu']")
	private WebElement SentBox2;
	
	public ComposE_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	
	public void ComposeMail() throws InterruptedException
	{
		Thread.sleep(3000);
		Menu.click();
		Thread.sleep(3000);
		CreateMail.click();
		
	}
	
	 
	public void MailObjects() throws InterruptedException, AWTException
	{
		
		To.sendKeys("manigandanp14@gmail.com");
		
	/*	
		Robot r = new Robot();
		 r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
	    To.sendKeys("manigandan.ec95@gmail.com");
	    
	    */
	    
        Thread.sleep(1000);
        Subject.sendKeys("HI");
        MessageArea.sendKeys("HELLO HAVE A GOOD DAY");
        Thread.sleep(5000);
       // To.sendKeys("manigandan.p95@gmail.com");
		//Thread.sleep(2000);
        
      
	}
/*public void FileUpload() throws InterruptedException
{
	
	File f = new File("./commondatas/Resume.docx");
	String Absloutepathoffile = f.getAbsolutePath();
	Attachment.sendKeys(Absloutepathoffile);
	
	Thread.sleep(5000);

	Send.click();
}*/
public void Smiley() throws InterruptedException, AWTException
{
/*	Emote.click();
	Thread.sleep(2000);
	ESMIL.sendKeys("face");
	Thread.sleep(3000);
	Robot r = new Robot();
	r.keyPress(KeyEvent.VK_DOWN);
	r.keyRelease(KeyEvent.VK_DOWN);
	
    r.keyPress(KeyEvent.VK_ENTER);
	r.keyRelease(KeyEvent.VK_ENTER);
	r.keyPress(KeyEvent.VK_RIGHT);
	r.keyRelease(KeyEvent.VK_RIGHT);
	r.keyPress(KeyEvent.VK_ENTER);
	r.keyRelease(KeyEvent.VK_ENTER);
	
	*/
	
	
	Send.click();
	
}
 
public void VerifyMsgSent() throws InterruptedException
{
	Thread.sleep(3000);
	SentBox.click();
	SentBox2.click();
}



}
