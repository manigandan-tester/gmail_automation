package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DraftboX_POM {
	@FindBy(xpath="//div[@role='button'and@class='T-I T-I-KE L3']")
	private WebElement CreateMail;
	
	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="//input[@class='agP aFw']")
	public WebElement To;
	
	@FindBy(xpath="//input[@name='subjectbox']")
	private WebElement Subject;
	
	@FindBy(xpath="//div[@class='Am Al editable LW-avf tS-tW']")
	private WebElement MessageArea;

	@FindBy(xpath="(//div[@class='J-J5-Ji J-Z-I-Kv-H'])[21]")
	private WebElement Delete;
	
	@FindBy(xpath="//img[@aria-label='Save & close']")
	private WebElement MsgClose;
	
	@FindBy(xpath="(//span//a[@class='J-Ke n0'])[5]")
	private WebElement DraftBox;
	
	@FindBy(xpath="//div[@class='TO nZ aiq']")
	private WebElement DraftBox2;
	
	
	public DraftboX_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void DraftTest() throws InterruptedException
	{
		
		Thread.sleep(2000);
		Menu.click();
		Thread.sleep(3000);
		CreateMail.click();
		Thread.sleep(2000);
		To.sendKeys("manigandanp14@gmail.com");
		Thread.sleep(1000);
		Subject.sendKeys("HI");
		MessageArea.sendKeys("HELLO HAVE A GOOD DAY");
		Thread.sleep(2000);
		}
	
	public void Delete()
	{
		Delete.click();
	}
	
	public void CloseAndSave()
	{
		MsgClose.click();
	}
	public void DraftOpen()
	{
		//DraftBox2.click();
		DraftBox.click();
	}
	
	

}
