package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ListofMenu_POM {
	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="(//div[@class='G-asx J-J5-Ji'])[1]")
	private WebElement More2;
	
	@FindBy(xpath="//div[@class='TO aBP']")
	private WebElement IMBOX;
	
	@FindBy(xpath="(//div[@class='qj '])[1]")
	private WebElement Inbox;
	
	@FindBy(xpath="(//div[@class='qj '])[2]")
	private WebElement Starred;
	
	@FindBy(xpath="(//div[@class='qj '])[3]")
	private WebElement Snooze;
	
	@FindBy(xpath="(//div[@class='qj '])[4]")
	private WebElement Sent;
	
	@FindBy(xpath="(//div[@class='qj '])[5]")
	private WebElement Draft;
	
	@FindBy(xpath="(//div[@class='qj '])[6]")
	private WebElement Important;
	
	@FindBy(xpath="(//div[@class='qj '])[7]")
	private WebElement Chats;
	
	@FindBy(xpath="(//div[@class='qj '])[8]")
	private WebElement Scheduled;
	
	@FindBy(xpath="(//div[@class='qj '])[9]")
	private WebElement AllMail;
	
	@FindBy(xpath="(//div[@class='qj '])[10]")
	private WebElement Spam;
	
	@FindBy(xpath="(//div[@class='qj '])[11]")
	private WebElement Trash;
	
	
	
	public ListofMenu_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void AllMENU() throws InterruptedException
	{
		Menu.click();
		Thread.sleep(2000);
		Inbox.click();
		Thread.sleep(2000);
        Starred.click();
		Thread.sleep(2000);
        Snooze.click();
		Thread.sleep(2000);
        Sent.click();
		Thread.sleep(2000);
        Draft.click();
		Thread.sleep(2000);
		More2.click();
		Thread.sleep(2000);
        Important.click();
		Thread.sleep(2000);
		Chats.click();
		Thread.sleep(2000);
		Scheduled.click();
		Thread.sleep(2000);
		AllMail.click();
		Thread.sleep(2000);
		Spam.click();
		Thread.sleep(2000);
		Trash.click();
		Thread.sleep(2000);

		
	}
	
	
}
