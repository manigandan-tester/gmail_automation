package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReplyFrwD_POM {
	@FindBy(xpath="(//table//td[@class='yX xY '])[1]")
	private WebElement ClickMsg; 
	
	@FindBy(xpath="//span[@class='ams bkH']")
	private WebElement Replybutton; 
	
	@FindBy(xpath="//div[@aria-label='Message Body']")
	private WebElement MsgArea; 
	
	@FindBy(xpath="//span[@class='ams bkG']")
	private WebElement Frwdbutton; 
	
	@FindBy(xpath="//input[@class='agP aFw']")
	private WebElement ToFrwd; 
	
	@FindBy(xpath="//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']")
	private WebElement Sendbutton; 
	
	
	public ReplyFrwD_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void Reply()
	{
		ClickMsg.click();
	}
	
	public void ReplyMsg() throws InterruptedException
	{
		Replybutton.click();
		MsgArea.sendKeys("Hey Hi Have a Good Day");
		Thread.sleep(2000);
	    Sendbutton.click();

	}
	
	public void Frwd() throws InterruptedException
	{
		Frwdbutton.click();
		ToFrwd.sendKeys("manigandan.ec95@gmail.com");
		Thread.sleep(2000);
	    Sendbutton.click();
	}

}
