package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchBoX_POM {
	@FindBy(name="q")
	private WebElement Search; 
	
	@FindBy(xpath="//button[@aria-label='Advanced search options']")
	private WebElement SearchOptions;
	
	@FindBy(xpath="//input[@class='ZH nr aQa']")
	private WebElement SOFrom;
	
	@FindBy(xpath="//input[@class='ZH nr aQf']")
	private WebElement SOTo;
	
	@FindBy(xpath="//input[@class='ZH nr aQd']")
	private WebElement SOSubject;
	
	@FindBy(xpath="//input[@class='ZH nr aQb']")
	private WebElement SOWords;
	
	@FindBy(xpath="(//label[@class='bs3'])[1]")
	private WebElement SOCheckBox;
	
	@FindBy(xpath="(//input[@class='nr'])[2]")
	private WebElement SOCalendar;
	
	@FindBy(xpath="//div[@class='T-I J-J5-Ji Zx aQe T-I-atl L3']")
	private WebElement SOSearch;
	
	
	
	
	
	public SearchBoX_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void ADSearch()
	{
		SearchOptions.click();
		SOFrom.sendKeys("tengineer44@gmail.com");
		SOTo.sendKeys("mani9710220464@gmail.com");
		SOSubject.sendKeys("SearchBoxTesting");
		SOWords.sendKeys("Advance");
		SOCheckBox.click();
		SOSearch.click();
		
	}
	
}
