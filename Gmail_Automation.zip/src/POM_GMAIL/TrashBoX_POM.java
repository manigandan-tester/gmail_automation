package POM_GMAIL;

import java.awt.AWTException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrashBoX_POM {
	@FindBy(xpath="//div[@role='button'and@class='T-I T-I-KE L3']")
	private WebElement CreateMail;
	
	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="(//a[@class='J-Ke n0'])[4]")
	private WebElement SentBox;
	
	@FindBy(xpath="//div[@class='TN bzz aHS-bnu']")
	private WebElement SentBox2;
	
	@FindBy(xpath="(//div[@class='xS'])[8]")
	private WebElement SentMsg;
	
	@FindBy(xpath="(//div[@class='ar9 T-I-J3 J-J5-Ji'])[3]")
	private WebElement DeltMsg;
	
	@FindBy(xpath="(//div[@class='qj '])[11]")
	private WebElement Trash;
	
	@FindBy(xpath="(//div[@class='G-asx J-J5-Ji'])[1]")
	private WebElement More2;
	
	@FindBy(xpath="(//tbody//tr[@class='zA yO byw'])[3]")
	private WebElement ClickMsg;
	
	
	public TrashBoX_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void DeletedMsg() throws InterruptedException, AWTException
	{
		Menu.click();
		SentBox.click();
		SentBox2.click();
		Menu.click();
		Thread.sleep(3000);
	//	Robot r = new Robot();
/*		r.keyPress(KeyEvent.VK_DOWN);
	    r.keyRelease(KeyEvent.VK_DOWN);
	    r.keyPress(KeyEvent.VK_ENTER);
	    r.keyRelease(KeyEvent.VK_ENTER);
	*/
		ClickMsg.click();
		Thread.sleep(3000);
		SentMsg.click();
		Thread.sleep(3000);
		DeltMsg.click();
		Thread.sleep(2000);
		More2.click();
    	Trash.click();
	    Thread.sleep(2000);
	
	
	    
	
	}
}
