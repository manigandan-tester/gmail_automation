package POM_GMAIL;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllMail_POM {
	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="//span[@class='J-Ke n4 ah9 aiu']")
	private WebElement More;
	
	@FindBy(xpath="(//div[@class='G-asx J-J5-Ji'])[1]")
	private WebElement More2;
	
	@FindBy(xpath="(//div[@class='aio UKr6le'])[9]")
	private WebElement Allmail;
	
	@FindBy(xpath="//div[@class='T-I J-J5-Ji amD T-I-awG T-I-ax7 T-I-Js-Gs L3']")
	private WebElement FrwdMsgPage;
	
	@FindBy(xpath="(//div[@class='T-I J-J5-Ji amD T-I-awG T-I-ax7 T-I-Js-IF L3'])")
	private WebElement BkwdMsgPage;
	
	@FindBy(xpath="//span[@class='T-Jo J-J5-Ji']")
	private WebElement Checkbox;
	
	@FindBy(xpath="(//div[@class='G-asx T-I-J3 J-J5-Ji'])[5]")
	private WebElement Checkbox2;
	
	@FindBy(xpath="(//div[@class='G-asx T-I-J3 J-J5-Ji'])[5]")
	private WebElement CBOptions;
	
	@FindBy(xpath="(//div[@class='asa'])[22]")
	private WebElement AddOption1;
	
	@FindBy(xpath="(//div[@class='T-I J-J5-Ji nf T-I-ax7 L3'])[2]")
	private WebElement AddOption2;
	
	@FindBy(xpath="(//div[@class='G-Ni J-J5-Ji'])[5]")
	private WebElement ALLCB;
	
	@FindBy(xpath="")
	private WebElement Markread;
	
	@FindBy(xpath="(//div[@class='J-N-Jz'])[17]")
	private WebElement Markunread;
	
	@FindBy(xpath="(//div[@class='T-I J-J5-Ji nf T-I-ax7 L3'])[2]")
	private WebElement AddOption3;
	
	public AllMail_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	
	}

public void Allmails() throws InterruptedException, AWTException
{
	Menu.click();
	More2.click();
	Allmail.click();
	FrwdMsgPage.click();
	Thread.sleep(3000);
	BkwdMsgPage.click();
	Thread.sleep(3000);
	AddOption1.click();
	Thread.sleep(2000);
	Robot r = new Robot();
	r.keyPress(KeyEvent.VK_DOWN);
    r.keyRelease(KeyEvent.VK_DOWN);
    r.keyPress(KeyEvent.VK_ENTER);
    r.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(3000);
	Menu.click();
	Thread.sleep(1000);
	Checkbox2.click();
	ALLCB.click();
	AddOption2.click();
	Thread.sleep(2000);
	r.keyPress(KeyEvent.VK_DOWN);
    r.keyRelease(KeyEvent.VK_DOWN);
    r.keyPress(KeyEvent.VK_ENTER);
    r.keyRelease(KeyEvent.VK_ENTER);
    Thread.sleep(2000);
    Checkbox2.click();
    Checkbox2.click();	
    AddOption2.click();
	Thread.sleep(2000);
	r.keyPress(KeyEvent.VK_DOWN);
    r.keyRelease(KeyEvent.VK_DOWN);
    r.keyPress(KeyEvent.VK_DOWN);
    r.keyRelease(KeyEvent.VK_DOWN);
    r.keyPress(KeyEvent.VK_ENTER);
    r.keyRelease(KeyEvent.VK_ENTER);
    Thread.sleep(2000);
    Checkbox2.click();
    Checkbox2.click();	
    AddOption2.click();
	Thread.sleep(2000);
	r.keyPress(KeyEvent.VK_DOWN);
    r.keyRelease(KeyEvent.VK_DOWN);
    r.keyPress(KeyEvent.VK_DOWN);
    r.keyRelease(KeyEvent.VK_DOWN);
    r.keyPress(KeyEvent.VK_ENTER);
    r.keyRelease(KeyEvent.VK_ENTER);
}




	
}
