package POM_GMAIL;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MultiMSG_POM {
	@FindBy(xpath="//div[@role='button'and@class='T-I T-I-KE L3']")
	private WebElement CreateMail;
	
	@FindBy(xpath="//div[@aria-label='Main menu']")
	private WebElement Menu;
	
	@FindBy(xpath="//div[@class='TN bzz aHS-bnu']")
	public WebElement Sent;
	
	@FindBy(xpath="//input[@class='agP aFw']")
	public WebElement To;
	
	@FindBy(xpath="//input[@name='subjectbox']")
	private WebElement Subject;
	
	@FindBy(xpath="//input[@class='agP aFw'and@id=':1ff']")
	private WebElement Cc;
	
	@FindBy(xpath="//input[@class='agP aFw'and@id=':1fh']")
	private WebElement Bcc;
	
	@FindBy(xpath="//div[@class='Am Al editable LW-avf tS-tW']")
	private WebElement MessageArea;
	
	@FindBy(xpath="//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']")
	private WebElement Send;
	
	
	public MultiMSG_POM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void MultiMail() throws InterruptedException, IOException, AWTException
	{
		/*
		Thread.sleep(2000);
		Menu.click();
		Thread.sleep(3000);
		CreateMail.click();
		Thread.sleep(2000);
		To.sendKeys("manigandanp14@gmail.com");
		Thread.sleep(1000);
		Subject.sendKeys("HI");
		MessageArea.sendKeys("HELLO HAVE A GOOD DAY");
		Thread.sleep(2000);
	
	*/
		Thread.sleep(2000);
		Menu.click();
		Thread.sleep(3000);
		CreateMail.click();
		Thread.sleep(2000);
		FileInputStream fis = new FileInputStream("./commondatas/Mail.txt");
		Properties p = new Properties();
		p.load(fis);
		String Mail1 = p.getProperty("mail1"); 
		String Mail2 = p.getProperty("mail2");
		String Mail3 = p.getProperty("mail3"); 
		String Mail4 = p.getProperty("mail4"); 
		String Mail5 = p.getProperty("mail5");
		To.sendKeys(Mail1);
		Robot r = new Robot();
		 r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		To.sendKeys(Mail2);
		 r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		To.sendKeys(Mail3);
		 r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		To.sendKeys(Mail4);
		 r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		To.sendKeys(Mail5);
		 r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		Subject.sendKeys("HI");
		MessageArea.sendKeys("HELLO HAVE A GOOD DAY");
		Thread.sleep(2000);
		
		Send.click();
		
		
	}
	public void VerifySent()
	{
		Sent.click();
	}
	
}
