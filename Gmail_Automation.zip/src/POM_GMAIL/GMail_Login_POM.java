package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GMail_Login_POM {
//	public static WebDriver driver;

	@FindBy(id="identifierId")
    private WebElement EmailID;

    @FindBy(xpath="//span[text()='Next']")
    private WebElement ENext;
    
    @FindBy(xpath="//input[@type='password'and@name='Passwd']")
    private WebElement Password;
    
    @FindBy(xpath="(//span[@class='VfPpkd-vQzf8d'])[2]")
    private WebElement PNext;
    
    @FindBy(xpath="//img[@class='gb_n gbii']")
    private WebElement LogoSignOut;
    
    @FindBy(xpath="//div[text()='Sign out']")
    private WebElement SignOut;
    
     
    
    
	public GMail_Login_POM (WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}

   public void setUserName(String un)
   {
	   EmailID.sendKeys(un);
   }
   public void ClickENext()
   {
	   ENext.click();
   }
   public void setPassword(String pw)
   {
	   Password.sendKeys(pw);
   }
   public void ClickPNext()
   {
	   PNext.click();
   }
   
   public void Signout() throws InterruptedException
   {
	   Thread.sleep(5000);
	   LogoSignOut.click();
	

   }
   public void signout()
   {
	   SignOut.click();
   }
/*
public void GO() throws InterruptedException
{
	EmailID.sendKeys("tengineer44@gmail.com");
    ENext.click();
    Thread.sleep(3000);
    Password.sendKeys("Test@123");
    PNext.click();

}
*/
}
