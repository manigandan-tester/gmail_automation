package POM_GMAIL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SentBoX_POM {
		
		@FindBy(xpath="//div[@aria-label='Main menu']")
		private WebElement Menu;

		@FindBy(xpath="(//a[@class='J-Ke n0'])[4]")
		private WebElement SentBox;
		
		@FindBy(xpath="//div[@class='TN bzz aHS-bnu']")
		private WebElement SentBox2;
		
		@FindBy(xpath="(//div[@class='G-asx T-I-J3 J-J5-Ji'])[5]")
		private WebElement Checkbox;
		
		@FindBy(xpath="(//div[@class='G-Ni J-J5-Ji'])[7]")
		private WebElement Refresh;
		
		@FindBy(xpath="(//div[@class='G-Ni J-J5-Ji'])[5]")
		private WebElement ALLCB;
		
		@FindBy(xpath="(//div[text()='None'and@class='J-N-Jz'])[2]")
		private WebElement NoneCB;
		
		@FindBy(xpath="(//div[text()='Read'and@class='J-N-Jz'])[2]")
		private WebElement ReadCB;
		
		@FindBy(xpath="(//div[text()='Unread'and@class='J-N-Jz'])[2]")
		private WebElement UnreadCB;
		
		@FindBy(xpath="(//div[text()='Starred'and@class='J-N-Jz'])[2]")
		private WebElement StarredCB;
		
		@FindBy(xpath="(//div[text()='Unstarred'and@class='J-N-Jz'])[2]")
		private WebElement UnstarredCB;

		@FindBy(xpath="//span[text()='Any time']")       
		private WebElement TimeFilter;
		
		@FindBy(xpath="//div[text()='Older than a week']")
		private WebElement WeekFilter;
		
		@FindBy(xpath="(//*[local-name()='svg'])[13]")
		private WebElement WFilter;
		
		@FindBy(xpath="//div[text()='Older than a month']")
	    private WebElement MFilter;
		
		@FindBy(xpath="//div[text()='Older than 6 months']")
	    private WebElement SMFilter;
		
		@FindBy(xpath="//div[text()='Older than a year']")
		private WebElement YMFilter;
		
		
		public SentBoX_POM(WebDriver driver)
		{
			PageFactory.initElements(driver, this);
		}
		
		
		public void SelectOptions() throws InterruptedException
		{
			Menu.click();
			SentBox.click();
			SentBox2.click();
			Thread.sleep(3000);
	        Menu.click();		
			Thread.sleep(3000);
			Refresh.click();
			ALLCB.click();
			Thread.sleep(3000);
			Checkbox.click();
			Thread.sleep(3000);
			NoneCB.click();
			Thread.sleep(2000);
			Checkbox.click();
			Thread.sleep(1000);
	        ReadCB.click();
	        Thread.sleep(2000);
			Checkbox.click();
			Thread.sleep(1000);
			UnreadCB.click();
			Thread.sleep(2000);
			Checkbox.click();
			Thread.sleep(1000);
			StarredCB.click();
			Thread.sleep(2000);
			Checkbox.click();
			Thread.sleep(1000);
			UnstarredCB.click();
			Thread.sleep(2000);
			
		}
		
		
		
		public void Filters() throws InterruptedException
		{
			Menu.click();
			SentBox.click();
			SentBox2.click();
			Thread.sleep(3000);
	        Menu.click();
	        Thread.sleep(3000);
			TimeFilter.click();
			Thread.sleep(3000);		
			WeekFilter.click();
			Thread.sleep(3000);
			WFilter.click();
			Thread.sleep(2000);
			MFilter.click();
			Thread.sleep(2000);
			WFilter.click();
		    Thread.sleep(3000);
		    SMFilter.click();
		    Thread.sleep(2000);
		    WFilter.click();
		    Thread.sleep(3000);
		    YMFilter.click();
		    Thread.sleep(3000);
		
		
		}
		
		
		
		
		
		
		
		
}
