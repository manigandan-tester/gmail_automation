package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.ListofMenu_POM;

public class TC_AllMenu extends Gmail_BaseTest {
	@Test(priority=1)
	public void ALLMenu_TC() throws InterruptedException, AWTException
	{

		Reporter.log("Output10",true);
		ListofMenu_POM AM = new ListofMenu_POM(driver);
		PageFactory.initElements(driver, AM );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		AM.AllMENU();
}
}