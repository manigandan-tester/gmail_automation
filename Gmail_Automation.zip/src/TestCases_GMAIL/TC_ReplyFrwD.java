package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.ReplyFrwD_POM;

public class TC_ReplyFrwD extends Gmail_BaseTest {
	@Test
	public void ReplyFrwd_TC() throws InterruptedException, AWTException
	{

		Reporter.log("Output7",true);
		ReplyFrwD_POM RF = new ReplyFrwD_POM(driver);
		PageFactory.initElements(driver, RF );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		RF.Reply();
		JavascriptExecutor Jse = (JavascriptExecutor) driver;
		Jse.executeScript("window, scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
        RF.ReplyMsg();
        Thread.sleep(3000);
        RF.Frwd();
		
		
		
	}
	
}
