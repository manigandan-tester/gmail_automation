package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.AllMail_POM;

public class TC_AllMail extends Gmail_BaseTest {
	@Test(priority=8)
	public void ALLMAIL_TC() throws InterruptedException, AWTException
	{

		Reporter.log("Output8",true);
		AllMail_POM ALM = new AllMail_POM(driver);
		PageFactory.initElements(driver, ALM );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		ALM.Allmails();




	}
}
