package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.SentBoX_POM;

public class TC_SentBoX extends Gmail_BaseTest{
	@Test(priority=5)
	public void TestSentMail() throws InterruptedException, AWTException 
	{

		SentBoX_POM	 SB = new SentBoX_POM(driver);
		PageFactory.initElements(driver, SB );


		Reporter.log("Output4",true);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		SB.SelectOptions();
		SB.Filters();
	}	
}
