package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.TrashBoX_POM;

public class TC_TrashBoX extends Gmail_BaseTest{
	@Test(priority=9)
	public void TRASH_TC() throws InterruptedException, AWTException
	{

		Reporter.log("Output9",true);
		TrashBoX_POM DM = new TrashBoX_POM(driver);
		PageFactory.initElements(driver, DM );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		DM.DeletedMsg();


	}
}
