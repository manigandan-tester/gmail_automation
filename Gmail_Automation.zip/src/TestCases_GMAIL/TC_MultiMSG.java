package TestCases_GMAIL;

import java.awt.AWTException;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.MultiMSG_POM;

public class TC_MultiMSG extends Gmail_BaseTest{
	@Test(priority=4)
	public void MultipleMSG() throws InterruptedException, AWTException, IOException 
	{

		MultiMSG_POM MMS = new MultiMSG_POM(driver);
		PageFactory.initElements(driver, MMS );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		MMS.MultiMail();
		Reporter.log("Output6",true);
		Thread.sleep(3000);
		MMS.VerifySent();
	}
}
