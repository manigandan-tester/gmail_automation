package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.SearchMsg_POM;

public class TC_SearchMsg extends Gmail_BaseTest {
	@Test
	public void SearchMessage_TC() throws InterruptedException, AWTException
	{

		Reporter.log("Output7",true);
		SearchMsg_POM SMG = new SearchMsg_POM(driver);
		PageFactory.initElements(driver, SMG );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		SMG.Searching();
		Thread.sleep(3000);
		JavascriptExecutor Jse = (JavascriptExecutor) driver;
		Jse.executeScript("window, scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		SMG.Download();
			
		

	}

}
