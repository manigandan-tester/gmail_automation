package TestCases_GMAIL;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.InboX_POM;

public class TC_InboX extends Gmail_BaseTest {

	@Test(priority=3)
	public void Inbox_TC() throws InterruptedException
	{

		Reporter.log("Output2",true);
		InboX_POM IB = new InboX_POM(driver);
		PageFactory.initElements(driver, IB );
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		IB.Menu.click();
		Thread.sleep(3000);
		IB .Primary.click();
		Thread.sleep(3000);
		IB.Social.click();
		Thread.sleep(3000);
		IB.Promotions.click();
		Thread.sleep(3000);
		String ParentHandle = driver.getWindowHandle();
		System.out.println(ParentHandle);
		IB.Details.click();
		Set<String> Handles = driver.getWindowHandles();		
		for(String Handle : Handles) {
			System.out.println(Handle);
			if(!Handle.equals(ParentHandle)) {
				driver.switchTo().window(Handle);
				IB.ShowDetails.click();
				Thread.sleep(2000);
				driver.close();

			}

		}
		driver.switchTo().window(ParentHandle);
		IB .Primary.click();
		Thread.sleep(3000);
		IB.Refresh.click();


	}
}
