package TestCases_GMAIL;

import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.SearchBoX_POM;

public class TC_SearchBoX extends Gmail_BaseTest{
	@Test(priority=7)
	public void Searchbox_TC() throws InterruptedException
	{

		Reporter.log("Output6",true);
		SearchBoX_POM SBX = new SearchBoX_POM(driver);
		PageFactory.initElements(driver, SBX );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		SBX.ADSearch();

}
}
