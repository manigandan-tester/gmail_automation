package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.DraftboX_POM;

public class TC_Draftbox extends Gmail_BaseTest {

	@Test(priority=6)
	public void DraftMsg() throws InterruptedException, AWTException 
	{

		DraftboX_POM DB = new DraftboX_POM(driver);
		PageFactory.initElements(driver, DB );

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Reporter.log("Output5",true);
		DB.DraftTest();
		DB.Delete();
		Thread.sleep(2000);
		DB.DraftOpen();
		Thread.sleep(2000);
		DB.DraftTest();
		DB.CloseAndSave();
		Thread.sleep(2000);
		DB.DraftOpen();


	}	
}
