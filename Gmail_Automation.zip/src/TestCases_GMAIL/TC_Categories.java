package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.CategorieS_POM;

public class TC_Categories extends Gmail_BaseTest {
	@Test(priority=2)
	public void Categories_Tc() throws InterruptedException, AWTException 
	{

		CategorieS_POM CAT = new CategorieS_POM(driver);
		PageFactory.initElements(driver, CAT );


		Reporter.log("Output12",true);	
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		CAT.Category();
		Thread.sleep(2000);
		JavascriptExecutor Jse = (JavascriptExecutor) driver;
		Jse.executeScript("window, scrollTo(0,document.body.scrollHeight)");
		CAT.CatOptions();
		
	}
	
}
