package TestCases_GMAIL;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

import CommonFunctions_GMAIL.Gmail_BaseTest;
import POM_GMAIL.ComposE_POM;

public class TC_Compose extends Gmail_BaseTest {
	@Test(priority=2)
	public void TestValidLogin() throws InterruptedException, AWTException 
	{

		ComposE_POM ICM = new ComposE_POM(driver);
		PageFactory.initElements(driver, ICM );


		Reporter.log("Output3",true);	
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		ICM.ComposeMail();
		ICM.MailObjects();
		ICM.Smiley();
		ICM.VerifyMsgSent();
		Thread.sleep(3000);



	}
}
